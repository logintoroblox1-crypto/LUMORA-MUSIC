package com.lumora.music;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    static WebView sWeb;
    private WebView web;
    private ValueCallback<Uri[]> filePicker;
    private static final int REQ_FILE = 1;

    /* Dipasang ke halaman: kirim judul/artis/cover/status putar ke sisi Android (tanpa mengubah index.html) */
    private static final String BRIDGE_JS =
        "(function(){if(window.__lb)return;window.__lb=1;var last='';setInterval(function(){try{"
        + "var s=queue[idx];if(!s)return;var p=!!playing();var k=s.id+'|'+p;"
        + "if(k!==last){last=k;LumoraNative.update(s.title||'',s.artist||'',s.img||'',p);}"
        + "}catch(e){}},500);})();";

    /* Jalankan perintah JS di halaman (dipakai notifikasi & pulau musik) */
    static void js(final String code) {
        final WebView w = sWeb;
        if (w == null) return;
        new Handler(Looper.getMainLooper()).post(() -> w.evaluateJavascript(code, null));
    }

    class Bridge {
        @JavascriptInterface
        public void update(final String t, final String a, final String i, final boolean p) {
            runOnUiThread(() -> {
                MusicService.push(getApplicationContext(), t, a, i, p);
                askOverlayOnce(p);
            });
        }
    }

    private void askOverlayOnce(boolean playing) {
        if (!playing || isFinishing() || Settings.canDrawOverlays(this)) return;
        SharedPreferences sp = getSharedPreferences("lumora", MODE_PRIVATE);
        if (sp.getBoolean("asked_overlay", false)) return;
        sp.edit().putBoolean("asked_overlay", true).apply();
        new AlertDialog.Builder(this)
            .setTitle("Aktifkan Pulau Musik")
            .setMessage("Izinkan \"Tampil di atas aplikasi lain\" supaya mini player melayang muncul di atas layar saat kamu keluar dari aplikasi.")
            .setPositiveButton("Buka pengaturan", (d, w) -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))))
            .setNegativeButton("Nanti", null)
            .show();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 2);
        }
        web = new WebView(this);
        sWeb = web;
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        web.addJavascriptInterface(new Bridge(), "LumoraNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(BRIDGE_JS, null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePicker != null) filePicker.onReceiveValue(null);
                filePicker = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePicker = null;
                    return false;
                }
                return true;
            }
        });

        if (b == null) web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        else web.restoreState(b);
    }

    @Override
    protected void onStart() {
        super.onStart();
        MusicService.setVisible(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        MusicService.setVisible(false);   /* app di latar belakang -> pulau musik muncul */
        web.resumeTimers();               /* jaga WebView tetap jalan supaya musik tidak berhenti */
    }

    @Override
    protected void onDestroy() {
        stopService(new Intent(this, MusicService.class));
        sWeb = null;
        web.destroy();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && filePicker != null) {
            filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            filePicker = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    /* Tombol back = pindah ke latar belakang (musik tetap jalan), bukan menutup aplikasi */
    @Override
    public void onBackPressed() { moveTaskToBack(true); }
}
