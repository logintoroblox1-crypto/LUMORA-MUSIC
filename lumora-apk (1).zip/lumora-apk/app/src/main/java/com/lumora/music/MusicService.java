package com.lumora.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;

/** Service foreground: menjaga proses tetap hidup, notifikasi kontrol musik, dan "Pulau Musik" melayang. */
public class MusicService extends Service {
    static MusicService instance;
    static String title = "", artist = "", coverFor = "";
    static boolean playing = false, visible = true, dismissed = false;
    static Bitmap cover;

    static final String CH = "lumora_music";
    static final String A_TOGGLE = "lumora.TOGGLE", A_NEXT = "lumora.NEXT", A_PREV = "lumora.PREV";
    static final String JS_TOGGLE = "(playing()?pauseNow():resumeNow())", JS_NEXT = "nxt()", JS_PREV = "play(idx-1)";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private MediaSession session;
    private PowerManager.WakeLock wl;
    private WindowManager wm;
    private LinearLayout pill;
    private ImageView pCover;
    private ImageButton pPlay;
    private TextView pTitle, pArtist;
    private WindowManager.LayoutParams lp;
    private boolean pillShown = false;

    /* ---------- dipanggil dari MainActivity ---------- */
    static void push(Context c, String t, String a, String i, boolean p) {
        boolean newTrack = !t.equals(title) || !a.equals(artist);
        title = t; artist = a; playing = p;
        if (newTrack || p) dismissed = false;
        if (!i.equals(coverFor)) { coverFor = i; cover = null; loadCover(i); }
        if (instance != null) instance.refresh();
        else {
            try { c.startForegroundService(new Intent(c, MusicService.class)); } catch (Exception e) { }
        }
    }

    static void setVisible(boolean v) {
        visible = v;
        final MusicService m = instance;
        if (m != null) m.ui.post(m::updatePill);
    }

    private static void loadCover(final String url) {
        if (url.isEmpty()) return;
        new Thread(() -> {
            try {
                HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(8000); h.setReadTimeout(8000);
                Bitmap b = BitmapFactory.decodeStream(h.getInputStream());
                if (b != null && url.equals(coverFor)) {
                    cover = Bitmap.createScaledBitmap(b, 256, 256, true);
                    final MusicService m = instance;
                    if (m != null) m.ui.post(m::refresh);
                }
            } catch (Exception e) { }
        }).start();
    }

    /* ---------- lifecycle ---------- */
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH, "Pemutar musik", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        session = new MediaSession(this, "LumoraMusic");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { MainActivity.js("resumeNow()"); }
            @Override public void onPause() { MainActivity.js("pauseNow()"); }
            @Override public void onSkipToNext() { MainActivity.js(JS_NEXT); }
            @Override public void onSkipToPrevious() { MainActivity.js(JS_PREV); }
        });
        session.setActive(true);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lumora:music");

        Notification n = build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);
        refresh();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        String a = i == null ? null : i.getAction();
        if (A_TOGGLE.equals(a)) MainActivity.js(JS_TOGGLE);
        else if (A_NEXT.equals(a)) MainActivity.js(JS_NEXT);
        else if (A_PREV.equals(a)) MainActivity.js(JS_PREV);
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) { stopSelf(); }

    @Override
    public void onDestroy() {
        if (pillShown) { try { wm.removeView(pill); } catch (Exception e) { } pillShown = false; }
        if (wl != null && wl.isHeld()) wl.release();
        if (session != null) session.release();
        instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    /* ---------- notifikasi + sesi media ---------- */
    private PendingIntent act(String a) {
        Intent i = new Intent(this, MusicService.class).setAction(a);
        return PendingIntent.getService(this, a.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification build() {
        Intent open = new Intent(this, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent content = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title.isEmpty() ? "LUMORA MUSIC" : title)
            .setContentText(artist)
            .setLargeIcon(cover)
            .setContentIntent(content)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_previous), "Sebelumnya", act(A_PREV)).build())
            .addAction(new Notification.Action.Builder(Icon.createWithResource(this,
                playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play), playing ? "Jeda" : "Putar", act(A_TOGGLE)).build())
            .addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_next), "Berikutnya", act(A_NEXT)).build())
            .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2).setMediaSession(session.getSessionToken()))
            .build();
    }

    private void refresh() {
        if (playing && !wl.isHeld()) wl.acquire(6 * 60 * 60 * 1000L);
        else if (!playing && wl.isHeld()) wl.release();

        session.setPlaybackState(new PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS)
            .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f)
            .build());
        MediaMetadata.Builder mb = new MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, artist);
        if (cover != null) mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, cover);
        session.setMetadata(mb.build());

        getSystemService(NotificationManager.class).notify(1, build());
        updatePill();
    }

    /* ---------- Pulau Musik (jendela melayang) ---------- */
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void openApp() {
        startActivity(new Intent(this, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP));
    }

    private ImageButton btn(LinearLayout r, int res, final String js) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(res);
        b.setColorFilter(Color.WHITE);
        b.setBackground(null);
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setPadding(dp(6), dp(6), dp(6), dp(6));
        b.setOnClickListener(v -> MainActivity.js(js));
        r.addView(b, new LinearLayout.LayoutParams(dp(38), dp(38)));
        return b;
    }

    private void buildPill() {
        final LinearLayout r = new LinearLayout(this);
        pill = r;
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(8), dp(6), dp(10), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2000000);
        bg.setCornerRadius(dp(40));
        r.setBackground(bg);

        pCover = new ImageView(this);
        pCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        pCover.setClipToOutline(true);
        pCover.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(20)); }
        });
        r.addView(pCover, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        pTitle = new TextView(this);
        pTitle.setTextColor(Color.WHITE); pTitle.setTextSize(13); pTitle.setTypeface(null, Typeface.BOLD);
        pTitle.setSingleLine(true); pTitle.setEllipsize(TextUtils.TruncateAt.END); pTitle.setMaxWidth(dp(130));
        pArtist = new TextView(this);
        pArtist.setTextColor(0xFFB0B0B0); pArtist.setTextSize(11);
        pArtist.setSingleLine(true); pArtist.setEllipsize(TextUtils.TruncateAt.END); pArtist.setMaxWidth(dp(130));
        col.addView(pTitle); col.addView(pArtist);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cl.setMargins(dp(10), 0, dp(6), 0);
        r.addView(col, cl);

        btn(r, android.R.drawable.ic_media_previous, JS_PREV);
        pPlay = btn(r, android.R.drawable.ic_media_pause, JS_TOGGLE);
        btn(r, android.R.drawable.ic_media_next, JS_NEXT);

        lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(12);

        /* geser = pindahkan, ketuk = buka aplikasi, tekan lama = tutup pulau sampai lagu berikutnya */
        r.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved; long t0;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = lp.x; sy = lp.y; dx = e.getRawX(); dy = e.getRawY(); moved = false; t0 = System.currentTimeMillis();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                        if (Math.abs(mx) > dp(6) || Math.abs(my) > dp(6)) moved = true;
                        if (moved) {
                            lp.x = sx + (int) mx; lp.y = sy + (int) my;
                            try { wm.updateViewLayout(pill, lp); } catch (Exception x) { }
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            if (System.currentTimeMillis() - t0 > 600) { dismissed = true; updatePill(); }
                            else openApp();
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private void updatePill() {
        boolean want = !visible && !dismissed && !title.isEmpty() && Settings.canDrawOverlays(this);
        if (!want) {
            if (pillShown) { try { wm.removeView(pill); } catch (Exception e) { } pillShown = false; }
            return;
        }
        if (pill == null) buildPill();
        pTitle.setText(title);
        pArtist.setText(artist);
        pPlay.setImageResource(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play);
        if (cover != null) pCover.setImageBitmap(cover); else pCover.setImageResource(R.drawable.ic_launcher);
        if (!pillShown) {
            wm.addView(pill, lp);
            pillShown = true;
            pill.setAlpha(0f); pill.setScaleX(0.6f); pill.setScaleY(0.6f);
            pill.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();
        }
    }
}
